public class Edge {
    public Node end1;
    public Node end2;

    public Edge(Node _end1,Node _end2){
        end1=_end1;
        end2=_end2;
    }
}
