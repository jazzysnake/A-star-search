public class Node {
    public int id;

    public double x;
    public double y;

    public Node(int _id, double _x,double _y){
        x=_x;
        y=_y;
        id=_id;
    }
}
