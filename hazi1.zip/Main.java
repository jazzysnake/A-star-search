//import java.util.ArrayList;
import java.util.Scanner;

public class Main {

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    int p= sc.nextInt();
    int n= sc.nextInt();
    int e= sc.nextInt();

    //ArrayList<Node> nodes= new ArrayList<Node>();

    for (int i = 0; i < p; i++) {
        String line = sc.nextLine();
        System.out.println(line);
    }
    sc.nextLine();
    for (int i = 0; i < n; i++) {
        String line = sc.nextLine();
        System.out.println(line);
    }
    sc.nextLine();
    for (int i = 0; i < e; i++) {
        String line = sc.nextLine();
        System.out.println(line);
    }

    sc.close();
}
}